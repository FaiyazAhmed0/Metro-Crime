# Metro Crime: Open World — Galaxy M31s Edition

Target profile: Samsung Galaxy M31s, Exynos 9611, Mali-G72 MP3, 6 GB RAM.

## Performance settings
- Godot 4.3, Compatibility renderer
- 960×540 viewport
- 30 FPS cap
- No real-time shadows, SSAO, SSR or glow
- 95 m camera far distance
- Simplified city geometry and materials

## Prototype gameplay
On-foot movement, red car driving, enter/exit, checkpoint mission and touchscreen controls.

## Build an Android APK using GitHub Actions (no PC required)

1. Create a **new private repository** on GitHub, for example `metro-crime-m31s`.
2. On your phone, open the repository in GitHub and choose **Add file → Upload files**.
3. Upload the contents of this project folder (not just the ZIP file). Keep `.github/workflows/android-apk.yml` in its exact folder path and upload `project.godot`, `scenes/`, and `scripts/`.
4. Commit the upload to the `main` branch.
5. Open the repository's **Actions** tab. Select **Build Metro Crime Android APK**. If it has not run automatically, tap **Run workflow**.
6. Wait for the workflow to finish with a green check mark.
7. Open the successful run and download the artifact named **Metro-Crime-M31s-Android-APK**. Extract it to get `Metro_Crime_M31s.apk`.
8. Open the APK on your Galaxy M31s and approve installation if Android asks.

The workflow uses Godot 4.3 and matching Android export templates, Java 17, and Android SDK 34. It builds an ARM64 debug APK for testing. It is not a Play Store release build. Actual game performance must be tested on-device; 30 FPS is a target cap, not a guarantee.

## Important
This is an editable Godot source project. The ZIP itself is **not** an APK. The APK is produced only after the GitHub Actions workflow completes successfully. If the workflow fails, open the failed run and share the error log so the build can be corrected.
