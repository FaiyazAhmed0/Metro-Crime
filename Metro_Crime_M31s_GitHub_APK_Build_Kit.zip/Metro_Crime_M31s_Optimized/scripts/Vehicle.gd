extends CharacterBody3D
var throttle=0.0
var steer=0.0
var boost=false
var speed=0.0
func _ready():
	set_physics_process(false)
	var m=MeshInstance3D.new()
	var bm=BoxMesh.new()
	bm.size=Vector3(1.9,0.65,3.7)
	m.mesh=bm
	var mat=StandardMaterial3D.new()
	mat.albedo_color=Color(0.72,0.1,0.07)
	mat.roughness=0.55
	m.material_override=mat
	m.position.y=0.34
	add_child(m)
	var c=CollisionShape3D.new()
	var sh=BoxShape3D.new()
	sh.size=Vector3(1.9,0.85,3.7)
	c.shape=sh
	c.position.y=0.34
	add_child(c)
func set_mobile_input(v,b):
	steer=v.x
	throttle=-v.y
	boost=b
func _physics_process(delta):
	var t=throttle
	var s=steer
	if Input.is_key_pressed(KEY_W): t=1
	if Input.is_key_pressed(KEY_S): t=-1
	if Input.is_key_pressed(KEY_A): s=-1
	if Input.is_key_pressed(KEY_D): s=1
	speed=move_toward(speed,t*(20 if boost else 14),delta*10)
	rotate_y(-s*delta*(0.85+abs(speed)*0.02))
	var f=-global_basis.z
	velocity.x=f.x*speed
	velocity.z=f.z*speed
	velocity.y=-0.8
	move_and_slide()
