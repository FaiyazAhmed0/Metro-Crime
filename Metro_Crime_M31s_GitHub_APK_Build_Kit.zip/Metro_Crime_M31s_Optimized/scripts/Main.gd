extends Node3D
const PLAYER=preload("res://scripts/Player.gd")
const CAR=preload("res://scripts/Vehicle.gd")
var player
var car
var driving=false
var camera
var mission_done=false
var target=Vector3(0,0.5,-62)
var keys={"up":false,"down":false,"left":false,"right":false,"run":false}
var mission_label
var status
func _ready():
	Engine.max_fps=30
	var env=WorldEnvironment.new()
	var e=Environment.new()
	e.background_mode=Environment.BG_SKY
	e.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color=Color(0.65,0.68,0.72)
	e.ambient_light_energy=0.7
	e.glow_enabled=false
	e.ssao_enabled=false
	e.ssr_enabled=false
	env.environment=e
	add_child(env)
	var sun=DirectionalLight3D.new()
	sun.rotation_degrees=Vector3(-45,-30,0)
	sun.shadow_enabled=false
	add_child(sun)
	box("Ground",Vector3(0,-0.6,0),Vector3(150,1,150),Color(0.2,0.3,0.22))
	for x in range(-3,4):
		for z in range(-3,4):
			if abs(x)<=1 or abs(z)<=1: continue
			var h=randf_range(6,16)
			var c=[Color(0.36,0.39,0.43),Color(0.48,0.43,0.37),Color(0.3,0.36,0.42)][(x*x+z*z)%3]
			box("Building",Vector3(x*20,h/2,z*20),Vector3(randf_range(7,10),h,randf_range(7,10)),c)
	box("Road NS",Vector3(0,0,0),Vector3(11,0.12,150),Color(0.1,0.11,0.13))
	box("Road EW",Vector3(0,0,0),Vector3(150,0.12,11),Color(0.1,0.11,0.13))
	for i in range(-7,8,2):
		box("Lane",Vector3(0,0.08,i*9),Vector3(0.16,0.04,3),Color(0.8,0.75,0.5))
		box("Lane",Vector3(i*9,0.08,0),Vector3(3,0.04,0.16),Color(0.8,0.75,0.5))
	player=CharacterBody3D.new()
	player.set_script(PLAYER)
	player.position=Vector3(3,1.2,5)
	add_child(player)
	car=CharacterBody3D.new()
	car.set_script(CAR)
	car.position=Vector3(0,0.65,7)
	add_child(car)
	var ring=MeshInstance3D.new()
	var torus=TorusMesh.new()
	torus.inner_radius=1.8
	torus.outer_radius=2.1
	torus.rings=8
	torus.ring_segments=12
	ring.mesh=torus
	ring.position=target
	var rm=StandardMaterial3D.new()
	rm.albedo_color=Color(0.1,0.9,0.35)
	rm.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
	ring.material_override=rm
	add_child(ring)
	camera=Camera3D.new()
	camera.current=true
	camera.fov=78
	camera.far=95
	add_child(camera)
	ui()
func box(n,p,s,c):
	var b=StaticBody3D.new()
	b.name=n
	b.position=p
	add_child(b)
	var m=MeshInstance3D.new()
	var bm=BoxMesh.new()
	bm.size=s
	m.mesh=bm
	var mat=StandardMaterial3D.new()
	mat.albedo_color=c
	mat.roughness=1
	mat.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
	m.material_override=mat
	b.add_child(m)
	var col=CollisionShape3D.new()
	var sh=BoxShape3D.new()
	sh.size=s
	col.shape=sh
	b.add_child(col)
func ui():
	var layer=CanvasLayer.new()
	add_child(layer)
	var panel=ColorRect.new()
	panel.position=Vector2(12,10)
	panel.size=Vector2(390,68)
	panel.color=Color(0,0,0,0.65)
	layer.add_child(panel)
	mission_label=Label.new()
	mission_label.position=Vector2(12,7)
	mission_label.text="MISSION 01 • Reach the green marker"
	mission_label.add_theme_font_size_override("font_size",18)
	panel.add_child(mission_label)
	status=Label.new()
	status.position=Vector2(12,38)
	status.text="M31s mode • 30 FPS cap"
	status.add_theme_font_size_override("font_size",14)
	panel.add_child(status)
	add_control(layer,"▲",Vector2(75,395),"up")
	add_control(layer,"▼",Vector2(75,465),"down")
	add_control(layer,"◀",Vector2(8,430),"left")
	add_control(layer,"▶",Vector2(142,430),"right")
	add_control(layer,"RUN",Vector2(205,430),"run")
	action(layer,"ENTER / EXIT",Vector2(790,430),toggle_car)
	action(layer,"MISSION",Vector2(790,355),hint)
	action(layer,"RESET",Vector2(790,505),reset_game)
func add_control(parent,txt,pos,key):
	var b=Button.new()
	b.text=txt
	b.position=pos
	b.size=Vector2(64,60)
	parent.add_child(b)
	b.button_down.connect(func():keys[key]=true)
	b.button_up.connect(func():keys[key]=false)
func action(parent,txt,pos,fn):
	var b=Button.new()
	b.text=txt
	b.position=pos
	b.size=Vector2(145,54)
	parent.add_child(b)
	b.pressed.connect(fn)
func toggle_car():
	if driving:
		player.global_position=car.global_position+Vector3(2.4,0.4,0)
		player.visible=true
		car.set_physics_process(false)
		driving=false
		status.text="On foot"
	elif player.global_position.distance_to(car.global_position)<6:
		driving=true
		player.visible=false
		car.set_physics_process(true)
		status.text="Driving • reach marker"
	else: status.text="Walk closer to the red car"
func hint(): status.text="Reach the green ring by foot or car"
func reset_game():
	player.global_position=Vector3(3,1.2,5)
	car.global_position=Vector3(0,0.65,7)
	player.visible=true
	car.set_physics_process(false)
	driving=false
	mission_done=false
	mission_label.text="MISSION 01 • Reach the green marker"
	status.text="Position reset"
func _physics_process(delta):
	var v=Vector2(float(keys["right"])-float(keys["left"]),float(keys["down"])-float(keys["up"]))
	if driving: car.set_mobile_input(v,keys["run"])
	else: player.set_mobile_input(v,keys["run"])
	var p=car.global_position if driving else player.global_position
	if not mission_done and Vector2(p.x-target.x,p.z-target.z).length()<4:
		mission_done=true
		mission_label.text="MISSION COMPLETE!"
		status.text="Checkpoint reached"
	var focus=car.global_position if driving else player.global_position
	var fwd=car.global_basis.z if driving else player.global_basis.z
	camera.global_position=camera.global_position.lerp(focus+fwd*7+Vector3.UP*3.8,0.12)
	camera.look_at(focus+Vector3.UP*1.1)
