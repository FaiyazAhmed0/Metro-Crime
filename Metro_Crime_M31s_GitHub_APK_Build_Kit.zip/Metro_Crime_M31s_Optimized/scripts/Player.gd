extends CharacterBody3D
var input=Vector2.ZERO
var sprint=false
func _ready():
	var m=MeshInstance3D.new()
	var cap=CapsuleMesh.new()
	cap.radius=0.38
	cap.height=1.65
	m.mesh=cap
	var mat=StandardMaterial3D.new()
	mat.albedo_color=Color(0.1,0.24,0.62)
	m.material_override=mat
	m.position.y=0.83
	add_child(m)
	var c=CollisionShape3D.new()
	var s=CapsuleShape3D.new()
	s.radius=0.38
	s.height=1.65
	c.shape=s
	add_child(c)
func set_mobile_input(v,r):
	input=v
	sprint=r
func _physics_process(delta):
	var v=input
	if Input.is_key_pressed(KEY_W): v.y=-1
	if Input.is_key_pressed(KEY_S): v.y=1
	if Input.is_key_pressed(KEY_A): v.x=-1
	if Input.is_key_pressed(KEY_D): v.x=1
	var d=Vector3(v.x,0,v.y).normalized()
	var speed=7.2 if sprint else 5.2
	velocity.x=d.x*speed
	velocity.z=d.z*speed
	if not is_on_floor(): velocity.y-=22*delta
	else: velocity.y=-0.4
	move_and_slide()
